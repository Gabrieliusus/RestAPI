﻿namespace SchoolProject
{
    public class Sum
    {
        public int ZahlA { get; set; }
        public int ZahlB { get; set; }
    }
}